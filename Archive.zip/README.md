# Hi!
Please check back for an update Sunday (2024 November 03) for publishing to the chrome extensions store.
